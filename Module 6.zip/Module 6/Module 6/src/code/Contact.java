package code;

/* David J Allen
CS 320 - Contact Class
Southern New Hampshire University */

import java.lang.IllegalArgumentException;

public class Contact { // opening bracket of class
	
	/* Strings that will be used in the code
	 * to refer to the contact */
	
	public String id; // Id of contact
	public String firstName; // First name of contact
	public String lastName; // Last name of contact
	public String phone; // Phone number of contact
	public String address; // Address of contact
	
	/* Parameter integers to establish
	 * max length of the strings */
	
	final int Id_Length = 10; // Sets max length parameter for id
	final int FirstName_Length = 10; // Sets max length parameter for first name
	final int LastName_Length = 10; // Sets max length parameter for last name
	final int Phone_Length = 10; // Sets max length parameter for phone number
	final int Address_Length = 30; // Sets max length parameter for address
	
	/* Code to create an instance of a contact
	 * utilizing the null and length
	 * parameters for input validation */
	
	public Contact(String id, String firstName, String lastName, String phone, String address) {
		// If id doesn't meet assignment parameters, throw exception message
		if(id == null || id.length() > Id_Length) {
			throw new IllegalArgumentException("ID not correct");
		}
		
		if(firstName == null || firstName.length() > FirstName_Length) {
			throw new IllegalArgumentException("First name not correct");
		}
		
		if(lastName == null || lastName.length() > LastName_Length) {
			throw new IllegalArgumentException("Last name not correct");
		}
		
		if(phone == null || phone.length() != Phone_Length) {
			throw new IllegalArgumentException("Phone number not correct");
		}
		
		if(address == null || address.length() > Address_Length) {
			throw new IllegalArgumentException("Address invalid entry");
		}
		
		// Else set the strings to the contact
		
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;
		
	}
	
	/* Get and set statements to create the contact
	 * if all parameters are met */
	
	// Get/Set first name
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		if(firstName == null || firstName.length() > FirstName_Length) {
			throw new IllegalArgumentException("First name too long");
		}
		this.firstName = firstName;
	}
	
	// Get/Set last name
	
	public String getLastName() {
			return lastName;
		}
	public void setLastName(String lastName) {
			if(lastName == null || lastName.length() > LastName_Length) {
				throw new IllegalArgumentException("Last name too long");
			}
			this.lastName = lastName;
		}
		
		// Get/Set phone number
		
	public String getPhone() {
			return phone;
		}
	public void setPhone(String phone) {
			if(phone == null || phone.length() != Phone_Length) {
				throw new IllegalArgumentException("Phone number doesn't match required length");
			}
			this.phone = phone;
		}
		
		// Get/Set address
		
	public String getAddress() {
			return address;
		}
	public void setAddress(String address) {
			if(address == null || address.length() > Address_Length) {
				throw new IllegalArgumentException("Address too long");
			}
			this.address = address;
		}
		
		// Statement to return contact id
		
	public String getId() {
			return id;
		}

	
} // Closing bracket of class