package code;

// Import statements
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class AppointmentService { // Opening bracket of class
  final public List<Appointment> appointmentList = new ArrayList<>(); // Creates new list

  // Uses UUID to randomize for string
  public String newUniqueId() {
    return UUID.randomUUID().toString().substring(
        0, Math.min(toString().length(), 10));
  }

  // Creates new appointment for list id
  public void newAppointment() {
    Appointment appt = new Appointment(newUniqueId());
    appointmentList.add(appt);
  }

  // Creates new appointment for list id, date
  public void newAppointment(Date date) {
    Appointment appt = new Appointment(newUniqueId(), date);
    appointmentList.add(appt);
  }

  // Creates new appointment for list date, description
  public void newAppointment(Date date, String description) {
    Appointment appt = new Appointment(newUniqueId(), date, description);
    appointmentList.add(appt);
  }

  // Removes appointment from list based on id
  public void deleteAppointment(String id) throws Exception {
    appointmentList.remove(searchForAppointment(id));
  }

  // Returns appointment list
  public List<Appointment> getAppointmentList()
  {
	  return appointmentList;
	  }

  // Searches list for matching id
  public Appointment searchForAppointment(String id) throws Exception {
    int index = 0;
    while (index < appointmentList.size()) {
      if (id.equals(appointmentList.get(index).getAppointmentId())) {
        return appointmentList.get(index);
      }
      index++;
    }
    // If id is not in list throw exception
    throw new Exception("The appointment does not exist!");
  }
} // Closing bracket of class