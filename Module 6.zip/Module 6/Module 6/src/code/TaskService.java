/* David J Allen
   CS 320 - Contact Class
   Southern New Hampshire University */

package code;

// Import statement

import java.util.ArrayList;


public class TaskService { // Opening bracket of class
	
	// Declares an array list of Task named tasks
	private ArrayList<Task> tasks;
	public TaskService() {
		tasks = new ArrayList<>();
	}
	
	// Code to add task to list
	public void addTask(String id, String name, String description) throws Exception {
		Task newTask = new Task(id, name, description);
		//If there is nothing in list add task
		if (tasks.isEmpty()) {
			tasks.add(newTask);
		}
		// If the list isn't empty, iterate through list
		else {
			for(int i = 0; i < tasks.size(); i++) {
				// If the id is already in the list, throw exception message
				if(tasks.get(i).getId().equals(newTask.getId())) {
					throw new Exception("Id already exists");
				}
			}
			// If the id isn't in the list add the new task to the list
			tasks.add(newTask);
		}
	}
	
	// Code to delete a task from the list based on id
	public void deleteTask(String id) throws Exception {
		tasks.remove(findTaskIndex(id));
	}
	
	// Code to update a task in the list
	public void updateTask(String id, String name, String description) throws Exception {
		// Updates to index of matching id
		int indexToUpdate = findTaskIndex(id);
		// Update for name and description
		tasks.get(indexToUpdate).setName(name);
		tasks.get(indexToUpdate).setDescription(description);
	}
	
	// Returns task
	
	public Task getTask(String id) throws Exception {
		return tasks.get(findTaskIndex(id));
	}
	
	// Returns array list
	
	public ArrayList<Task> getTasks() {
		return tasks;
	}
	
	// Finds index of task in list
	
	private int findTaskIndex(String id) throws Exception {
		// Initializes at index and boolean
		int i = 0;
		boolean taskFound = false;
		
		// If the list is empty throw exception message
		if (tasks.size() == 0) {
			throw new Exception("There are no tasks");
		}
		
		// While the matching id is not found keep searching list
		while(!taskFound) {
			if(!tasks.get(i).getId().equals(id)) {
				i++;
				// If you reach end of list with no match throw exception message
				if(i >= tasks.size()) {
					throw new Exception("No task matches");
			}
		}
			// if id is found, change boolean to true
			else {
				taskFound = true;
			}
		}
		// Return task information
		return i;
	}
} // Closing bracket of class
