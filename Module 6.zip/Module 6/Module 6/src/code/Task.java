package code;

/* David J Allen
CS 320 - Task Class
Southern New Hampshire University */

import java.lang.IllegalArgumentException;

public class Task { // opening bracket of class
	
	/* Strings that will be used in the code
	 * to refer to the task */
	
	public String id; // Id of task
	public String name; // Name of task
	public String description; // Description of task
	
	/* Parameter integers to establish
	 * max length of the strings */
	
	final int Id_Length = 10; // Sets max length parameter for id
	final int Name_Length = 20; // Sets max length parameter for name
	final int Description_Length = 50; // Sets max length parameter for description

	
	/* Code to create an instance of a task
	 * utilizing the null and length
	 * parameters for input validation */
	
	public Task(String id, String name, String description) {
		// If id doesn't meet assignment parameters, throw exception message
		if(id == null || id.length() > Id_Length) {
			throw new IllegalArgumentException("ID not correct");
		}
		
		if(name == null || name.length() > Name_Length) {
			throw new IllegalArgumentException("Name not correct");
		}
		
		if(description == null || description.length() > Description_Length) {
			throw new IllegalArgumentException("Description not correct");
		}
		
		// Else set the strings to the task
		
		this.id = id;
		this.name = name;
		this.description = description;
		
	}
	
	/* Get and set statements to create the task
	 * if all parameters are met */
	
	// Get/Set name
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		if(name == null || name.length() > Name_Length) {
			throw new IllegalArgumentException("Name too long");
		}
		this.name = name;
	}
	
	// Get/Set description
	
	public String getDescription() {
			return description;
		}
	public void setDescription(String description) {
			if(description == null || description.length() > Description_Length) {
				throw new IllegalArgumentException("Description too long");
			}
			this.description = description;
		}

		
		// Statement to return task id
		
	public String getId() {
			return id;
		}

	
} // Closing bracket of class