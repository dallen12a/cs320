/* David J Allen
   CS 320 - Contact Class
   Southern New Hampshire University */

package code;

// Import statement

import java.util.ArrayList;


public class ContactService { // Opening bracket of class
	
	// Declares an array list of contact named contacts
	private ArrayList<Contact> contacts;
	public ContactService() {
		contacts = new ArrayList<>();
	}
	
	// Code to add contact to list
	public void addContact(String id, String firstName, String lastName, String phone, String address) throws Exception {
		Contact newContact = new Contact(id, firstName, lastName, phone, address);
		//If there is nothing in list add contact
		if (contacts.isEmpty()) {
			contacts.add(newContact);
		}
		// If the list isn't empty, iterate through list
		else {
			for(int i = 0; i < contacts.size(); i++) {
				// If the id is already in the list, throw exception message
				if(contacts.get(i).getId().equals(newContact.getId())) {
					throw new Exception("Id already exists");
				}
			}
			// If the id isn't in the list add the new contact to the list
			contacts.add(newContact);
		}
	}
	
	// Code to delete a contact from the list based on id
	public void deleteContact(String id) throws Exception {
		contacts.remove(findContactIndex(id));
	}
	
	// Code to update a contact in the list
	public void updateContact(String id, String firstName, String lastName, String phone, String address) throws Exception {
		// Updates to index of matching id
		int indexToUpdate = findContactIndex(id);
		// Update for first name, last name, phone number, and address
		contacts.get(indexToUpdate).setFirstName(firstName);
		contacts.get(indexToUpdate).setLastName(lastName);
		contacts.get(indexToUpdate).setPhone(phone);
		contacts.get(indexToUpdate).setAddress(address);
	}
	
	// Returns contact
	
	public Contact getContact(String id) throws Exception {
		return contacts.get(findContactIndex(id));
	}
	
	// Returns array list
	
	public ArrayList<Contact> getContacts() {
		return contacts;
	}
	
	// Finds index of contact in list
	
	private int findContactIndex(String id) throws Exception {
		// Initializes at index and boolean
		int i = 0;
		boolean contactFound = false;
		
		// If the list is empty throw exception message
		if (contacts.size() == 0) {
			throw new Exception("There are no contacts");
		}
		
		// While the matching id is not found keep searching list
		while(!contactFound) {
			if(!contacts.get(i).getId().equals(id)) {
				i++;
				// If you reach end of list with no match throw exception message
				if(i >= contacts.size()) {
					throw new Exception("No contact matches");
			}
		}
			// if id is found, change boolean to true
			else {
				contactFound = true;
			}
		}
		// Return contact information
		return i;
	}
} // Closing bracket of class
