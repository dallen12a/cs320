package code;

/* David J Allen
CS 320 - Appointment Class
Southern New Hampshire University */

//Import statement
import java.util.Date;

public class Appointment { // Starting bracket of class

//Declaration of int/string for class
final public int ID_LENGTH;
final public int DESCRIPTION_LENGTH;
final public String DEFAULT;
public String appointmentId;
public Date appointmentDate;
public String description;

// Set maximum length for id and description
// Create default for data
{
 ID_LENGTH = 10;
 DESCRIPTION_LENGTH = 50;
 DEFAULT = "Default";
}

// Initialize date, id, and description
public Appointment() {
 Date today = new Date();
 appointmentId = DEFAULT;
 appointmentDate = today;
 description = DEFAULT;
}

// Update for id
public Appointment(String id) {
 Date today = new Date();
 updateAppointmentId(id);
 appointmentDate = today;
 description = DEFAULT;
}

// Update for id and date
public Appointment(String id, Date date) {
 updateAppointmentId(id);
 updateDate(date);
 description = DEFAULT;
}

// Update for id, date, and description
public Appointment(String id, Date date, String description) {
 updateAppointmentId(id);
 updateDate(date);
 updateDescription(description);
}

// Sets criteria for update appointment id
public void updateAppointmentId(String id) {
	 // Throw error if id is empty or too long
 if (id == null) {
   throw new IllegalArgumentException("Appointment ID cannot be empty.");
 } else if (id.length() > ID_LENGTH) {
   throw new IllegalArgumentException("Appointment ID invalid");
   // Otherwise set id
 } else {
   this.appointmentId = id;
 }
}

// Returns id
public String getAppointmentId()
{
	  return appointmentId;
	  
}

// Sets criteria for update appointment date
public void updateDate(Date date) {
	// Throw error if date is empty or in the past
 if (date == null) {
   throw new IllegalArgumentException("Appointment date cannot be empty.");
 } else if (date.before(new Date())) {
   throw new IllegalArgumentException(
       "Cannot make appointment in the past.");
   // Otherwise set date
 } else {
   this.appointmentDate = date;
 }
}

// Return date
public Date getAppointmentDate()
{
	  return appointmentDate;
	  }

// Sets criteria for update appointment description
public void updateDescription(String description) {
	// Throw error if description is empty or too long
 if (description == null) {
   throw new IllegalArgumentException(
       "Appointment description cannot be empty.");
 } else if (description.length() > DESCRIPTION_LENGTH) {
   throw new IllegalArgumentException(
       "Appointment description invalid");
  // Otherwise set description
 } else {
   this.description = description;
 }
}
// Return description
public String getDescription()
{
	  return description;
	  }
}