/* Module Four J Task Class
   CS 320 - Task Class
   Southern New Hampshire University */

package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import code.Task;
import code.TaskService;

@SuppressWarnings("unused")

class TaskServiceTest { // Opening bracket of class

	// Test adding new task

	@Test
	void testAddTask() throws Exception {
		TaskService taskService = new TaskService();
		taskService.addTask("CS320", "Module Four", "Task Class");
		
		
		Task task = taskService.getTask("CS320");
		assertEquals(task.getId(), "CS320");
		assertEquals(task.getName(), "Module Four");
		assertEquals(task.getDescription(), "Task Class");
		
	}
	
	// Test updating task
	
	@Test
	void testUpdateTask() throws Exception {
		TaskService taskService = new TaskService();
		taskService.addTask("CS320", "Module Four", "Task Class");
		taskService.updateTask("CS320", "Module Null", "School Class");
		
		
		Task task = taskService.getTask("CS320");
		assertEquals(task.getId(), "CS320");
		assertEquals(task.getName(), "Module Null");
		assertEquals(task.getDescription(), "School Class");
	}
	
	// Test deleting task
	
	@Test
	void testDeleteTask() throws Exception {
		TaskService taskService = new TaskService();
		assertEquals(taskService.getTasks().size(),0);
		// add task for test
		taskService.addTask("CS123", "Module Null", "School Class");
		assertEquals(taskService.getTasks().size(),1);
		// delete task for test
		taskService.deleteTask("CS123");
		assertEquals(taskService.getTasks().size(),0);
	}

} // Closing bracket of class
