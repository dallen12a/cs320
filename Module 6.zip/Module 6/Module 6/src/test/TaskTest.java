package test;

/* Module Four J Task Class
   CS 320 - Task Class
   Southern New Hampshire University */

import code.Task;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import code.Task;

@SuppressWarnings("unused")

public class TaskTest { // Opening bracket of class
	
	// Length and null test for task id
	
	@Test
	void testTaskIdLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("CS320000000", "Module Four", "Task Class");
		});
	} //close id length test
	
	@Test
	void testIdNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task(null, "Module Four", "Task Class");
		});
	} //close id null test
	
	
	//Length and null tests for task name
	
	@Test
	void testNameLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("CS320", "Module 12345678945612", "Task Class");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("CS320", "Module Four", "Task Class");
			task.setName("Module 12345678945612");
		});
	} //close name length test
	
	@Test
	void testNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("CS320", null, "Task Class");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("CS320", "Module Four", "Task Class");
			task.setName(null);
		});
		
	} //close name null test
	
	
	// Length and null tests for description
	
		@Test
		void testDescriptionLength() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				Task task = new Task("CS320", "Module Four", "Writing An Assignment For A Class To Test The Code!!!!!!!!!!!!!");
			});
		
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("CS320", "Module Four", "Task Class");
			task.setDescription("Writing An Assignment For A Class To Test The Code!!!!!!!!!!!!!");
		});
		
		} //close description length test
		
		
		@Test
		void testDescriptionNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				Task task = new Task("CS320", "Module Four", null);
			});
			
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				Task task = new Task("CS320", "Module Four", "Task Class");
				task.setDescription(null);
			});
			
		} //close description null test
		
		
} // Closing bracket of class


