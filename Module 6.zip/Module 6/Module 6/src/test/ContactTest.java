package test;

/* David J Allen
   CS 320 - Contact Class
   Southern New Hampshire University */

// Import statements

import code.Contact;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

@SuppressWarnings("unused")

public class ContactTest { // Opening bracket of class
	
	// Length and null test for contact id
	
	@Test
	void testContactIdLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("CS320000000", "David", "Allen", "5181234567", "123 Center Way");
		});
	} //close id length test
	
	@Test
	void testIdNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact(null, "David", "Allen", "5181234567", "123 Center Way");
		});
	} //close id null test
	
	
	//Length and null tests for contact first name
	
	@Test
	void testFirstNameLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("CS320", "Bartholomew", "Allen", "5181234567", "123 Center Way");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("CS320", "David", "Allen", "5181234567", "123 Center Way");
			contact.setFirstName("Bartholomew");
		});
	} //close first name length test
	
	@Test
	void testFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("CS320", null, "Allen", "5181234567", "123 Center Way");
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("CS320", "David", "Allen", "5181234567", "123 Center Way");
			contact.setFirstName(null);
		});
		
	} //close first name null test
	
	
	// Length and null tests for last name
	
		@Test
		void testLastNameLength() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				Contact contact = new Contact("CS320", "David", "Williamsburg", "5181234567", "123 Center Way");
			});
		
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("CS320", "David", "Allen", "5181234567", "123 Center Way");
			contact.setLastName("Williamsburg");
		});
		
		} //close last name length test
		
		
		@Test
		void testLastNameNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				Contact contact = new Contact("CS320", "David", null, "5181234567", "123 Center Way");
			});
			
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				Contact contact = new Contact("CS320", "David", "Allen", "5181234567", "123 Center Way");
				contact.setLastName(null);
			});
			
		} //close last name null test
		
		
		// Length and null tests for phone number
		
		@Test
		void testphoneLength() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				Contact contact = new Contact("CS320", "David", "Allen", "51812345678", "123 Center Way");
			});
			
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				Contact contact = new Contact("CS320", "David", "Allen", "5181234567", "123 Center Way");
				contact.setPhone("51812345678");
			});
			
		} //close phone number length test
		
		@Test
		void testphoneNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				Contact contact = new Contact(null, "David", "Allen", null, "123 Center Way");
			});
			
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				Contact contact = new Contact("CS320", "David", "Allen", "5181234567", "123 Center Way");
				contact.setPhone(null);
			});
			
		} //close phone number null test
		
		
		// Length and null tests for address
		
		@Test
		void testAddressLength() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				Contact contact = new Contact("CS320", "David", "Allen", "5181234567", "P.O. Box 929 4189 Purple Boulevard");
			});
			
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				Contact contact = new Contact("CS320", "David", "Allen", "5181234567", "123 Center Way");
				contact.setAddress("P.O. Box 929 4189 Purple Boulevard");
			});
			
		} //close address length test
		
		@Test
		void testAddressNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				Contact contact = new Contact(null, "David", "Allen", "5181234567", null);
			});
			
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				Contact contact = new Contact("CS320", "David", "Allen", "5181234567", "123 Center Way");
				contact.setAddress(null);
			});
			
		} //close address null test
		
} // Closing bracket of class


