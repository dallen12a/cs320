/* David J Allen
   CS 320 - Contact Class
   Southern New Hampshire University */

package test;

// Import statements
import code.Contact;
import code.ContactService;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

@SuppressWarnings("unused")

class ContactServiceTest { // Opening bracket of class

	// Test adding new contact

	@Test
	void testAddContact() throws Exception {
		ContactService contactService = new ContactService();
		contactService.addContact(("CS320"), ("David"), "Allen", "5181234567", "123 Center Way");
		
		
		Contact contact = contactService.getContact("CS320");
		assertEquals(contact.getId(), "CS320");
		assertEquals(contact.getFirstName(), "David");
		assertEquals(contact.getLastName(), "Allen");
		assertEquals(contact.getPhone(), "5181234567");
		assertEquals(contact.getAddress(), "123 Center Way");
		
	}
	
	// Test updating contact
	
	@Test
	void testUpdateContact() throws Exception {
		ContactService contactService = new ContactService();
		contactService.addContact("CS320", "David", "Allen", "5181234567", "123 Center Way");
		contactService.updateContact("CS320", "Adam", "Sandler", "5187654321", "123 Left Road");
		
		
		Contact contact = contactService.getContact("CS320");
		assertEquals(contact.getId(), "CS320");
		assertEquals(contact.getFirstName(), "Adam");
		assertEquals(contact.getLastName(), "Sandler");
		assertEquals(contact.getPhone(), "5187654321");
		assertEquals(contact.getAddress(), "123 Left Road");
	}
	
	// Test deleting contact
	
	@Test
	void testDeleteContact() throws Exception {
		ContactService contactService = new ContactService();
		assertEquals(contactService.getContacts().size(),0);
		// add contact for test
		contactService.addContact("8675309", "Adam", "Sandler", "5187654321", "123 Left Road");
		assertEquals(contactService.getContacts().size(),1);
		// delete contact for test
		contactService.deleteContact("8675309");
		assertEquals(contactService.getContacts().size(),0);
	}

} // Closing bracket of class
